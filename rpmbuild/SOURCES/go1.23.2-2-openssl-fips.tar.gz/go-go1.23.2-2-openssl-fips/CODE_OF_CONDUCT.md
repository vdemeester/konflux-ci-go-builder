# Code of Conduct

This project adopts the Go code of conduct: https://go.dev/conduct.